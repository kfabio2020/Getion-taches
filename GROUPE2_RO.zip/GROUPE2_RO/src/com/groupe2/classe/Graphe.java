package com.groupe2.classe;

/**
*
* @author Fabrice
*/

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;
import java.util.Queue;

public class Graphe {
	private int nbreNoeuds;
	private int nbreVertex;
	protected Noeud[][] listeNoeuds;

	public Graphe(Noeud[][] nds, int nbreVertex) {
		this.listeNoeuds = nds;
		this.nbreVertex = nbreVertex;
		this.nbreNoeuds = listeNoeuds.length;
	}

	// Vérifier si la personne à une tache ou non
	public boolean isNoeud(int i, int j) {
		if (listeNoeuds[i][j].getId() >= 0) {
			return true;
		}
		return false;
	}

	public boolean isExist(int line, Noeud noeud) {
		for (int i = 0; i < nbreVertex; i++) {
			if (listeNoeuds[line][i].getId() == noeud.getId()) {
				return true;
			}
		}
		return false;
	}

	public List<Noeud> neihghtbours(int index) {
		List<Noeud> edge = new ArrayList<Noeud>();

		for (int i = 0; i < nbreVertex; i++)
			if (isNoeud(index, i))
				edge.add(new Noeud(listeNoeuds[index][i].getId()));
		return edge;
	}

	public List<Noeud> index(Noeud noeud) {
		List<Noeud> edge = new ArrayList<Noeud>();

		for (int i = 0; i < listeNoeuds.length; i++)
			if (isExist(i, noeud))
				edge.add(new Noeud(i));

		return edge;
	}

	// Retourne le BFS de la source au puit
	public LinkedList<Noeud> pathBFS(Noeud source, Noeud puits) {

		boolean vue[] = new boolean[listeNoeuds.length];

		int[] niveau = new int[listeNoeuds.length];

		for (int i = 0; i < vue.length; i++) {

			vue[i] = false;
		}
		vue[source.getId()] = true;
		niveau[source.getId()] = 0;

		Queue<Noeud> queu = new ArrayDeque<Noeud>();

		LinkedList<Noeud> courtChemin = new LinkedList<Noeud>();

		queu.add(source);
		courtChemin.add(source);

		// Parcourrir tous les noeuds
		while (!queu.isEmpty()) {

			source = queu.poll();

			// Chercher les successeurs du noeud courant
			for (Noeud index : neihghtbours(source.getId())) {

				// S'il n'est pas visité on le visite
				if (vue[index.getId()] == false) {

					vue[index.getId()] = true;

					niveau[index.getId()] = niveau[source.getId()] + 1;

					queu.add(index);

					courtChemin.add(index);
				}
			}
		}
		return courtChemin;
	}


	//Affiche le chemin inverse du puit à la souce
	public boolean pathInvert(LinkedList<Noeud> chemin) {

		boolean isExist = false;

		Noeud puit = chemin.getLast();

		boolean seen[] = new boolean[chemin.size()];

		int niveau[] = new int[chemin.size()];

		for (int i = 0; i < seen.length; i++) {

			seen[i] = false;
		}
		seen[puit.getId()] = true;

		niveau[puit.getId()] = 0;

		Queue<Noeud> queu = new ArrayDeque<Noeud>();

		LinkedList<Noeud> cheminRetour = new LinkedList<Noeud>();

		queu.add(puit);

		cheminRetour.add(puit);

		// On parcourt tous les autres noeuds
		while (!queu.isEmpty()) {

			puit = queu.poll();

			// On verifie les successeurs du noeud actuel
			for (Noeud i : index(puit)) {

				// Si c'est un noeud et il n'est pas encore visite on le visite
				if (seen[i.getId()] == false) {

					seen[i.getId()] = true;

					niveau[i.getId()] = niveau[puit.getId()] + 1;

					queu.add(i);

					cheminRetour.add(i);
				} else if (niveau[puit.getId()] == niveau[i.getId()]) {

					return false;
				}
			}
		}
		for (int i = 0; i < cheminRetour.size(); i++)
			if (i == cheminRetour.size() - 1)
				System.out.println(cheminRetour.get(i).getId() + " \t\t\t|");
			else
				System.out.print(cheminRetour.get(i).getId() + "=>");

		return isExist;
	}

	// Cette methode renvoie le nombre de flot max depuit t jusqu'a s
	public int ff(Noeud s, Noeud t) {

		int flot_max = 0;
		LinkedList<Noeud> pathBfs = new LinkedList<Noeud>();
		pathBfs = pathBFS(s, t);

		List<Noeud> tache = index(pathBfs.getLast());
		List<Noeud> personne = neihghtbours(pathBfs.getFirst().getId());

		// le nombre de successeurs du noeud puit
		int nbrSucceur = tache.size();

		int[] nbrS = new int[nbrSucceur];
		Noeud[] couplage = new Noeud[nbrSucceur];
		for (int i = 0; i < couplage.length; i++) {

			couplage[i] = new Noeud(-1);
		}
		for (int i = 0; i < nbrSucceur; i++) {

			nbrS[i] = index(tache.get(i)).size();
		}
		for (int i = 0; i < nbrSucceur; i++) {

			int min = min_valTable(nbrS);

			Noeud noeudM = tache.get(min);

			for (Noeud pred : index(noeudM)) {

				// Procedure de marquage et d'augmentation de flot en verifiant toujours la loi
				// de Kirchoff est respectée
				if ((!in_array(couplage, pred)) && (couplage[min].getId() < 0)) {

					couplage[min] = pred;
					flot_max = flot_max + 1;
				}
			}
			nbrS[min] = nbrSucceur;
		}
		System.out.println("---------------------------------------------------------");
		System.out.println("| Flot Max : " + flot_max + " \t\t\t\t\t\t|");
		System.out.println("---------------------------------------------------------");

		for (int i = 0; i < couplage.length; i++) {

			int num = i + 1;
			System.out.println("|=> La tâche numéro : " + num + " sera effectué par la personne "
					+ getPositionNoeud(personne, couplage[i]) + " |");
		}
		System.out.println("---------------------------------------------------------");

		return nbrSucceur;
	}

	// Etant donné que une personne a droit d'effectuer juste une tache;
	// Cette methode verifie si une tache est deja affecter à une personne
	// Cette methode verifie si un element se trouve deja dans un tableau

	public boolean in_array(Noeud[] tab, Noeud n) {

		boolean exist = false;

		for (int i = 0; i < tab.length; i++) {

			if (tab[i].getId() == n.getId())
				exist = true;
		}
		return exist;
	}

	// Cette methode retoune l'index de la plus petite valeur du tableau donné en
	// parametre
	public int min_valTable(int[] tab) {

		int index = 0;
		int min = tab[0];

		for (int i = 0; i < tab.length; i++) {

			if (tab[i] < min) {

				min = tab[i];
				index = i;
			}
		}
		return index;
	}

	public int getPositionNoeud(List<Noeud> list, Noeud noeud) {

		int position = -1;

		for (int i = 0; i < list.size(); i++) {
			if (list.get(i).getId() == noeud.getId()) {

				position = i + 1;
			}
		}
		return position;
	}
}
