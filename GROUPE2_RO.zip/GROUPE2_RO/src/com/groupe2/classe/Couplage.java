package com.groupe2.classe;

/**
*
* @author Fabrice
*/

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.LinkedList;

public class Couplage {
	public static Graphe setMatrix(String fileName) {
		ArrayList<String> liste = new ArrayList<String>();
		Noeud[][] listNoeuds = null;
		BufferedReader reader;
		int sizeMatrix = 0;

		try {
			reader = new BufferedReader(new FileReader(fileName));
			String currentLine;
			while ((currentLine = reader.readLine()) != null) {
				liste.add(currentLine);
			}
			sizeMatrix = Integer.parseInt(liste.get(0));

			String person = "";

			for (int i = sizeMatrix + 1; i <= sizeMatrix * 2; i++) {
				if (i < sizeMatrix * 2)
					person += i + " ";
				else
					person += i;
			}
			liste.remove(0);

			liste.add(0, person);

			int width = sizeMatrix;
			int lenght = (sizeMatrix * 2) + 2;

			listNoeuds = new Noeud[lenght][width];

			for (int i = 0; i < lenght; i++) {
				for (int j = 0; j < width; j++) {
					listNoeuds[i][j] = new Noeud(-1);
				}
			}
			String[] s = liste.get(0).split(" ");

			for (int i = 0; i < s.length; i++) {
				listNoeuds[0][i] = new Noeud(Integer.parseInt(s[i]));
			}
			for (int i = 1; i <= sizeMatrix; i++) {
				String[] currentL = liste.get(i).split(" ");

				int ii = sizeMatrix + i;

				for (int j = 0; j < currentL.length; j++) {
					listNoeuds[ii][j] = new Noeud(Integer.parseInt(currentL[j]));
				}
			}
			for (int i = 1; i < sizeMatrix + 1; i++) {
				listNoeuds[i][0] = new Noeud(listNoeuds.length - 1);
			}

		} catch (FileNotFoundException e) {

			System.out.println("Source Date Not Found :" + e);

		} catch (IOException e) {

			System.out.println("Error " + e);
		}
		return new Graphe(listNoeuds, sizeMatrix);
	}

	public void run(String cheminFichier) {
		Graphe graphe = setMatrix(cheminFichier);

		System.out.println();

		// bfs path
		System.out.println("---------------------------------------------------------");
		System.out.println("|Chemin BFS :  \t\t\t\t\t\t|");
		System.out.println("---------------------------------------------------------");

		LinkedList<Noeud> pathBfs = new LinkedList<Noeud>();

		// Le nombre 11 correspond à 5 personnes et 5 taches. Si le nombre taches
		// augmente on doit changer le nombre 11

		pathBfs = graphe.pathBFS(new Noeud(0), new Noeud(11));

		for (int i = 0; i < pathBfs.size(); i++)
			if (i == pathBfs.size() - 1)
				System.out.println(pathBfs.get(i).getId() + " \t\t\t|");
			else
				System.out.print(pathBfs.get(i).getId() + "=>");

		// Chemin invert path BFS
		System.out.println("---------------------------------------------------------");
		System.out.println("|Chemin invert BFS :  \t\t\t\t\t|");
		System.out.println("---------------------------------------------------------");

		boolean exist = graphe.pathInvert(pathBfs);

		// max flot
		System.out.println("---------------------------------------------------------");
		System.out.println("|Ford Fulkerson :  \t\t\t\t\t|");

		int flot_max = graphe.ff(new Noeud(0), new Noeud(11));
	}

}
