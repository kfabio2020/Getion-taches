package com.groupe2.classe;

/**
*
* @author Fabrice
*/
import java.util.ArrayList;

public class Noeud {
	private int idNoeud;
	private int nbreVoisin;
	private ArrayList<Noeud> ListSuccesseurs;

	public Noeud(int id) {

		this.idNoeud = id;
	}

	public int getId() {

		return this.idNoeud;
	}

	// Retourne le nombre de voisins
	public int getNbrVoisins() {

		return this.nbreVoisin;
	}

	// Modifie le nombre de voisins
	public void setNbrVoissins(int nbreVoisin) {

		this.nbreVoisin = nbreVoisin;
	}

	// Retourne le nombre de successeurs
	public int getNbrSuccesseur() {

		return ListSuccesseurs.size();
	}

	public void setSuccesseur(Noeud noeudS) {

		this.ListSuccesseurs.add(noeudS);
	}
}
